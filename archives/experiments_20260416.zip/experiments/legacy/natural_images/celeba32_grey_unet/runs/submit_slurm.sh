#!/bin/bash
#SBATCH --job-name=celeba32_grey_unet
#SBATCH --account=berzelius-2025-NNN
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --gpus=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --time=24:00:00
#SBATCH --output=/proj/berzelius-2025-NNN/parameterization_boundary/experiments/natural_images/celeba32_grey_unet/runs/slurm_%A_%a.out
#SBATCH --error=/proj/berzelius-2025-NNN/parameterization_boundary/experiments/natural_images/celeba32_grey_unet/runs/slurm_%A_%a.out
#SBATCH --array=0-62

module load Python/3.10.4-GCCcore-11.3.0
source /proj/berzelius-2025-NNN/envs/parambnd/bin/activate

cd /proj/berzelius-2025-NNN/parameterization_boundary
python -m experiments.natural_images.celeba32_grey_unet.run --run-index ${SLURM_ARRAY_TASK_ID} --manifest experiments/natural_images/celeba32_grey_unet/runs/run_manifest.json
