"""Image experiment family."""
