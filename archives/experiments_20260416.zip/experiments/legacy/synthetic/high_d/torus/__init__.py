"""Synthetic torus experiment."""
