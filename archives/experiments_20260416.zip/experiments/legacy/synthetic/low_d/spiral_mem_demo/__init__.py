"""Standalone spiral memorization demo."""
