"""Synthetic experiment family."""
