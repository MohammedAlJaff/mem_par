"""GMM subspace study."""
