"""MNIST n-sweep study."""
